#ifndef ZEROONEPACK_H
#define ZEROONEPACK_H

#include <vector>
#include <string>

using namespace std;

class zeroonepack
{
private:

    vector<int> values;
    vector<int> weights;
    int total;
    int count;
    int matcol;
    int matrow;
    int** calcMatrix;
    int* matrixHolder;
    int nowpack;
    int nowthing;
    int lastcomepack;
    int lastcomething;
public:
    zeroonepack();
    ~zeroonepack();
    bool initPack(vector<int>,vector<int>,int);
    bool step();
    void finish();
    void clear();
    int** getMatrix();
    int getlastpack();
    int getlastthing();
    int getnowpack();
    int getnowthing();
};

#endif // ZEROONEPACK_H
