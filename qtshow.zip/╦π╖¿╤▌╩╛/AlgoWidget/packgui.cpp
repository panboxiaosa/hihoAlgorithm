#include "packgui.h"
#include "ui_packgui.h"
#include <QDebug>
#include <QColor>

PackGUI::PackGUI(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PackGUI)
{
    ui->setupUi(this);
    this->setWindowTitle("0-1 BackPack");
    this->setFixedSize(this->width(),this->height());
    initpack();
}

PackGUI::~PackGUI()
{
    delete ui;
}

void PackGUI::on_pushButton_3_clicked()
{
    on_PackGUI_destroyed();
}

void PackGUI::initpack(){
    vector<int> values;
    vector<int> weights;
    values.push_back(6);
    values.push_back(3);
    values.push_back(5);
    values.push_back(4);
    values.push_back(6);
    weights.push_back(2);
    weights.push_back(2);
    weights.push_back(6);
    weights.push_back(5);
    weights.push_back(4);
    total = 10;
    thing = values.size();
    problem.initPack(values,weights,total);
    calcMatrix = problem.getMatrix();
    setMatrix();
}

void PackGUI::on_PackGUI_destroyed()
{
    delete ui;
    close();
}


void PackGUI::setMatrix(){

    ui->tableWidget->clear();
    ui->tableWidget->setColumnCount(total);
    ui->tableWidget->setRowCount(thing);

    for(int i = 1; i <= thing; i++){
        for(int j = 1; j <= total; j++){
            ui->tableWidget->setItem(i-1,j-1,new QTableWidgetItem(QString::number(calcMatrix[i][j])));
        }
    }
    int lastpack = problem.getlastpack();
    int lastthing = problem.getlastthing();
    int nowpack = problem.getnowpack();
    int nowthing = problem.getnowthing();
    if(lastpack == 0 && lastthing== 0){
        return;
    }
    ui->tableWidget->item(nowthing - 1,nowpack - 1)->setBackgroundColor(Qt::red);
    if(lastpack < 1 || lastthing < 1)
        return;
    ui->tableWidget->item(lastthing - 1,lastpack - 1)->setBackgroundColor(Qt::gray);
}

void PackGUI::on_pushButton_clicked()
{
    problem.step();
    setMatrix();
}

void PackGUI::on_pushButton_2_clicked()
{
    problem.finish();
    setMatrix();
}
