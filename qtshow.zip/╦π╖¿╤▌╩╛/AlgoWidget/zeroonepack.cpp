#include "zeroonepack.h"
using namespace std;


zeroonepack::zeroonepack(){

}

zeroonepack::~zeroonepack(){
    delete[] matrixHolder;
}

//initialize
bool zeroonepack::initPack(vector<int> values,vector<int> weights,int total){
    if(values.size() != weights.size()){
        return false;
    }

    this->values = values;
    this->weights = weights;
    this->total = total;
    this->count = values.size();
    this->matcol = total + 1;
    this->matrow = count + 1;

    this->matrixHolder = new int[matcol*matrow];
    this->calcMatrix = new int* [matrow];

    for(int i = 0; i <= count; i++){
        calcMatrix[i] = matrixHolder + matcol * i;
    }

    for(int i = 0; i <= count; i++){
        for(int j = 0; j <= total; j++){
            calcMatrix[i][j] = 0;
        }
    }
    lastcomepack = 0;
    lastcomething = 0;
    nowpack = 1;
    nowthing = 1;
    return true;
}

//one step
bool zeroonepack::step(){
    if(nowpack == total + 1)
        return false;
    if(weights[nowthing - 1] > nowpack){
        calcMatrix[nowthing][nowpack] = calcMatrix[nowthing-1][nowpack];
        lastcomepack = nowpack;
        lastcomething = nowthing - 1;
    }else if(calcMatrix[nowthing-1][nowpack]>calcMatrix[nowthing-1][nowpack-weights[nowthing - 1]] + values[nowthing-1]){
        calcMatrix[nowthing][nowpack] = calcMatrix[nowthing-1][nowpack];
        lastcomepack = nowpack;
        lastcomething = nowthing - 1;
    }else{
        calcMatrix[nowthing][nowpack] = calcMatrix[nowthing-1][nowpack-weights[nowthing - 1]] + values[nowthing-1];
        lastcomepack = nowpack - weights[nowthing-1];
        lastcomething = nowthing - 1;
    }

    if(nowthing == count){
        nowthing = 1;
        nowpack++;
    }else{
        nowthing++;
    }
    return true;
}

void zeroonepack::finish(){
    while(step());
}

void zeroonepack::clear(){
    delete[] matrixHolder;
}

int** zeroonepack::getMatrix(){
    return this->calcMatrix;
}


int zeroonepack::getlastpack(){
    return lastcomepack;
}

int zeroonepack::getlastthing(){
    return lastcomething;
}

int zeroonepack::getnowpack(){
    if(nowthing == 1){
        return nowpack - 1;
    }else{
        return nowpack;
    }
}

int zeroonepack::getnowthing(){
    if(nowthing == 1){
        return count;
    }else{
        return nowthing - 1;
    }

}
