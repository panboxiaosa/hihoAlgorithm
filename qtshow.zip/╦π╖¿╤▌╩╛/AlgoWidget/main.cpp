#include "dialog.h"
#include <QApplication>
#include <QTextCodec>


using namespace std;

int main(int argc, char *argv[])
{
    QTextCodec::setCodecForCStrings(QTextCodec::codecForName("UTF-8"));
    QApplication a(argc, argv);
    Dialog w;
    w.show();

    return a.exec();
}
