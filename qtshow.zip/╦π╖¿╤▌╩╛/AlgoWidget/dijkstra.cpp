#include "dijkstra.h"
#include <strstream>
using namespace std;

dijkstra::dijkstra()
{
}

dijkstra::~dijkstra(){
    delete matrixHolder;
}

void dijkstra::clear(){
    delete[] matrixHolder;
    route.clear();
    initPoint.clear();
    initEdge.clear();
    addedPoint.clear();
    notAddedPoint.clear();
    eachDist.clear();
}

bool dijkstra::step(){
    if(notAddedPoint.empty()){
        return false;
    }
    if(status == 0){
        if(nextvisit == notAddedPoint.size()){
            int temp = notAddedPoint[minpoint];
            notAddedPoint.erase(notAddedPoint.begin() + minpoint);
            addedPoint.push_back(temp);
            minpoint = 0;
            mindist = MAXDIST;
            nextvisit = 0;
            status = 1;
        }else{
            int temp = eachDist[notAddedPoint[nextvisit]];
            if(temp < mindist){
                mindist = temp;
                minpoint = nextvisit;
            }
        nextvisit++;
        }
    }else{
        if(nextvisit == totalpoint){
            nextvisit = 0;
            status = 0;
        }else{
            int temp = eachDist[addedPoint.back()] + distMatrix[addedPoint.back()][nextvisit];
            if(temp < eachDist[nextvisit]){
                eachDist[nextvisit] = temp;
                route[nextvisit] = "";
                route[nextvisit] += route[addedPoint.back()];
                route[nextvisit] += "->";
                strstream ss;
                ss<<nextvisit;
                string temp;
                ss>>temp;
                route[nextvisit] += temp;
            }

            nextvisit++;
        }
    }
    return true;
}

void dijkstra::finish(){
    while(step());
}

void dijkstra::setInit(vector<int> points,vector<edge> edges,int start){
    this->initPoint = points;
    this->initEdge = edges;
    this->totalpoint = initPoint.size();
    matrixHolder = new int[totalpoint*totalpoint];
    distMatrix = new int*[totalpoint];
    for(int i = 0; i < totalpoint; i++){
        distMatrix[i] = matrixHolder + i*totalpoint;
    }

    for(int i = 0; i < totalpoint; i++){
        for(int j = 0; j < totalpoint; j++){
            distMatrix[i][j] = MAXDIST;
        }
    }

    for(int i = 0; i < totalpoint; i++){
        eachDist.push_back(MAXDIST);
    }

    for(int i = 0; i < totalpoint; i++){
        notAddedPoint.push_back(initPoint[i]);
    }

    for(int i = 0; i < totalpoint; i++){
        route.push_back("");
    }

    for(int i = 0; i < initEdge.size(); i++){
        distMatrix[initEdge[i].point1][initEdge[i].point2] = initEdge[i].length;
        distMatrix[initEdge[i].point2][initEdge[i].point1] = initEdge[i].length;
    }

    eachDist[start] = 0;

    nextvisit = 0;
    minpoint = 0;
    mindist = MAXDIST;
    status = 0;
}

vector<string>& dijkstra::getRoutes(){
    return route;
}

vector<int>& dijkstra::getDist(){
    return eachDist;
}

vector<int>& dijkstra::getAddedPoints(){
    return addedPoint;
}

int dijkstra::getnowvisit(){
    if(status == 0){
        return notAddedPoint[nextvisit - 1];
    }else{
        return initPoint[nextvisit - 1];
    }
}

int dijkstra::getminpoint(){
    return minpoint;
}

int dijkstra::getmindist(){
    return mindist;
}

int dijkstra::getstatus(){
    return status;
}
