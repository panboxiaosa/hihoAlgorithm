#ifndef PROCESSGUI_H
#define PROCESSGUI_H

#include <QDialog>

namespace Ui {
class ProcessGUI;
}

class ProcessGUI : public QDialog
{
    Q_OBJECT

public:
    explicit ProcessGUI(QWidget *parent = 0);
    ~ProcessGUI();

private slots:
    void on_ProcessGUI_destroyed();

    void on_pushButton_clicked();

private:
    Ui::ProcessGUI *ui;
};

#endif // PROCESSGUI_H
