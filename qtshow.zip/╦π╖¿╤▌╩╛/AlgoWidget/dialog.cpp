#include "dialog.h"
#include "ui_dialog.h"
#include "QDebug"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    this->setWindowTitle("Algorithm Presentation");
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_pushButton_clicked()
{
   pack = new PackGUI(this);
   pack->show();
}


void Dialog::on_pushButton_2_clicked()
{
    dijkstra = new dijkstraGUI(this);
    dijkstra->show();
}


void Dialog::on_pushButton_3_clicked()
{
    compress = new CompressGUI(this);
    compress->show();
}
