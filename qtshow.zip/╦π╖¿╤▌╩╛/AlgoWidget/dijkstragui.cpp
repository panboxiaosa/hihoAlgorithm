#include "dijkstragui.h"
#include "ui_dijkstragui.h"
#include <QDebug>
#include <stdlib.h>


dijkstraGUI::dijkstraGUI(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::dijkstraGUI)
{
    ui->setupUi(this);
    this->setFixedSize(this->width(),this->height());
    init();
    initDraw();
}

dijkstraGUI::~dijkstraGUI()
{
    delete ui;
}

void dijkstraGUI::on_pushButton_clicked()
{
    on_dijkstraGUI_destroyed();
}

void dijkstraGUI::on_dijkstraGUI_destroyed()
{
    close();
}

void dijkstraGUI::on_pushButton_2_clicked()
{
    problem.step();
    setwidget();
    drawDiagram();
}

void dijkstraGUI::initDraw(){
    scene = new QGraphicsScene();
    scene->setSceneRect(-200,-200,400,400);
    ui->graphicsView->setScene(scene);
    currentcolor = QColor(216,0,0,160);
    currentpen.setColor(currentcolor);
    currentbrush.setColor(currentcolor);
    currentbrush.setStyle(Qt::SolidPattern);
    addedbrush.setStyle(Qt::SolidPattern);
    pointfont.setBold(true);
    pointfont.setItalic(true);

    texts = new QGraphicsTextItem[10];
    lines = new QGraphicsLineItem[21];
    labels = new QGraphicsTextItem[21];

    for(int i = 0; i < 10; i++){
        int tempx = x[i]*32;
        int tempy = y[i]*32;
        texts[i].setPos(tempx + 2,tempy -10);
        texts[i].setScale(1.2);
        texts[i].setFont(pointfont);
        texts[i].setPlainText(QString::number(i));
        scene->addItem(texts + i);
    }

    for(int i = 0; i < 21; i++){
        int x1 = x[edges[i].point1] * 32;
        int x2 = x[edges[i].point2] * 32;
        int y1 = y[edges[i].point1] * 32;
        int y2 = y[edges[i].point2] * 32;

        lines[i].setLine(x1,y1,x2,y2);
        labels[i].setPos((x1+x2)/2 - 2,(y1+y2)/2 - 8);
        labels[i].setPlainText(QString::number(edges[i].length));
        scene->addItem(lines+i);
        scene->addItem(labels+i);
    }
    nowrect = new QGraphicsRectItem();
    nowrect->setPen(currentpen);
    nowrect->setBrush(currentbrush);

}

void dijkstraGUI::init(){

    int x0[10] = {-6,-4,-4,-4,-4,4,4,4,4,6};
    int y0[10] = {0,6,2,-2,-6,6,2,-2,-6,0};
    for(int i = 0; i < 10; i++){
        x.push_back(x0[i]);
        y.push_back(y0[i]);
    }
    int p1[21] = {0,0,0,0,1,2,3,1,2,2,2,3,4,4,5,6,7,5,6,7,8};
    int p2[21] = {1,2,3,4,2,3,4,5,5,6,7,7,7,8,6,7,8,9,9,9,9};
    int l[21] = {1,10,6,3,10,4,2,6,1,4,1,3,6,8,2,5,3,5,2,8,5};

    for(int i = 0 ; i < 21; i++){
        edge temp;
        temp.point1 = p1[i];
        temp.point2 = p2[i];
        temp.length = l[i];
        edges.push_back(temp);
    }
    vector<int> points;
    for(int i = 0; i < 10; i++){
        points.push_back(i);
    }
    problem.setInit(points,edges,0);

}

void dijkstraGUI::on_pushButton_3_clicked()
{
    while(problem.step()){
        drawDiagram();
    }
    setwidget();
}

void dijkstraGUI::setwidget(){
    ui->listWidget->clear();
    ui->listWidget_2->clear();
    vector<int> addedpoint = problem.getAddedPoints();
    vector<int> dist = problem.getDist();
    int status = problem.getstatus();
    if(status == 0){
        ui->lineEdit_3->setText("搜索最近点");
    }else {
        ui->lineEdit_3->setText("更新距离值");
    }
    vector<string> routes = problem.getRoutes();
    for(int i = 0; i < addedpoint.size(); i++){
        QString str = "到达";
        str += QString::number(addedpoint[i]);
        str += "  经过";
        str += routes[addedpoint[i]].c_str();
        str += "  距离为";
        str += QString::number(dist[addedpoint[i]]);
        ui->listWidget->addItem(new QListWidgetItem(str));
    }

    for(int i = 0; i < dist.size(); i++){
        QString str = "顶点 ";
        str += QString::number(i);
        str += "\t最短距离";
        str += QString::number(dist[i]);
        ui->listWidget_2->addItem(new QListWidgetItem(str));
    }
}


void dijkstraGUI::drawDiagram(){

    vector<int> added = problem.getAddedPoints();
    if(!added.empty()){
        QGraphicsEllipseItem* ellipse = new QGraphicsEllipseItem();

        int tempx = x[added.back()] * 32;
        int tempy = y[added.back()] * 32;
        ellipse->setBrush(addedbrush);
        ellipse->setRect(tempx - 8,tempy - 8, 16, 16);
        scene->addItem(ellipse);
    }

    int now = problem.getnowvisit();
    if(now < 0 || now > 9){
        scene->removeItem(nowrect);
        return;
    }
    int tempx = x[now]*32;
    int tempy = y[now]*32;
    scene->removeItem(nowrect);
    nowrect->setRect(tempx - 8, tempy - 8, 16,16);
    scene->addItem(nowrect);
}


