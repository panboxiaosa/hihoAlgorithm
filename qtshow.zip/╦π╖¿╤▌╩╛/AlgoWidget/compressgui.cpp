#include "compressgui.h"
#include "ui_compressgui.h"
#include <QColor>
#include <QDebug>

CompressGUI::CompressGUI(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CompressGUI)
{
    ui->setupUi(this);
    init();
}

CompressGUI::~CompressGUI()
{
    delete ui;
}

void CompressGUI::on_CompressGUI_destroyed()
{
    delete ui;
    close();
}

void CompressGUI::on_pushButton_clicked()
{
    on_CompressGUI_destroyed();
}

void CompressGUI::init(){
    int a[12] = {10, 12, 15, 255, 1, 2, 1, 1, 2, 2, 1, 1};
    problem.init(a,12);
}

void CompressGUI::on_pushButton_2_clicked()
{
    problem.step();
    setwidget();
}

void CompressGUI::setwidget(){
    ui->tableWidget->clear();
    int size = problem.getsize();
    ui->tableWidget->setRowCount(3);
    ui->tableWidget->setColumnCount(size);
    QStringList li;
    li<<"像素"<<"位数"<<"结果";
    ui->tableWidget->setVerticalHeaderLabels(li);
    int* pixl = problem.getpixl();
    int* pixels = problem.getpixels();
    int* result = problem.getresult();
    for(int i = 1; i <= size; i++){
        ui->tableWidget->setItem(0,i-1,new QTableWidgetItem(QString::number(pixels[i])));
        ui->tableWidget->setItem(1,i-1,new QTableWidgetItem(QString::number(pixl[i])));
        ui->tableWidget->setItem(2,i-1,new QTableWidgetItem(QString::number(result[i])));
    }
    int maxl = problem.getmaxl();
    int minval = problem.getminval();
    ui->lineEdit->setText(QString::number(maxl));
    ui->lineEdit_2->setText(QString::number(minval));

    int pos = problem.getpos();
    int cut = problem.getcut();

    ui->tableWidget->item(1,pos - 1)->setBackgroundColor(Qt::red);
    ui->tableWidget->item(1,pos - cut + 1)->setBackgroundColor(Qt::gray);
}

void CompressGUI::on_pushButton_3_clicked()
{
    problem.finish();
    setwidget();
}
