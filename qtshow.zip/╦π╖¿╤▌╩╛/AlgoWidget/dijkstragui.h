#ifndef DIJKSTRAGUI_H
#define DIJKSTRAGUI_H

#include <QDialog>
#include "dijkstra.h"
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsEllipseItem>
#include <QGraphicsLineItem>
#include <QGraphicsTextItem>
#include <QPen>
#include <QBrush>
#include <QColor>
#include <QGraphicsRectItem>
#include <QFont>

#include <vector>
using namespace std;

namespace Ui {
class dijkstraGUI;
}

class dijkstraGUI : public QDialog
{
    Q_OBJECT

public:
    explicit dijkstraGUI(QWidget *parent = 0);
    ~dijkstraGUI();
    void init();
    void setwidget();
    void initDraw();
    void drawDiagram();
private slots:
    void on_pushButton_clicked();

    void on_dijkstraGUI_destroyed();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::dijkstraGUI *ui;
    dijkstra problem;
    vector<int> x;
    vector<int> y;
    QGraphicsScene* scene;
    QGraphicsLineItem* lines;
    QGraphicsTextItem* texts;
    QGraphicsTextItem* labels;
    vector<edge> edges;
    QPen currentpen;
    QBrush currentbrush;
    QColor currentcolor;
    QBrush addedbrush;
    QGraphicsRectItem* nowrect;
    QFont pointfont;
};

#endif // DIJKSTRAGUI_H
