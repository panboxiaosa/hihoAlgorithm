#ifndef PACKGUI_H
#define PACKGUI_H

#include <QDialog>
#include <zeroonepack.h>

namespace Ui {
class PackGUI;
}

class PackGUI : public QDialog
{
    Q_OBJECT

public:
    explicit PackGUI(QWidget *parent = 0);
    ~PackGUI();
    void initpack();
    void setMatrix();

private slots:
    void on_pushButton_3_clicked();

    void on_PackGUI_destroyed();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::PackGUI *ui;
    zeroonepack problem;
    int ** calcMatrix;
    int total;
    int thing;
};

#endif // PACKGUI_H
