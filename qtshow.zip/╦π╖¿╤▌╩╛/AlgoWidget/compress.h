#ifndef COMPRESS_H
#define COMPRESS_H

class compress
{
public:
    compress();
    ~compress();
    bool step();
    void finish();
    void clear();
    int* getresult();
    int* getpixl();
    int* getpixels();
    int length(int input);
    int getpos();
    int getcut();
    int getmaxl();
    int getminval();
    int getsize();
    void init(int *input, int size);
private:
    int* pixels;
    int* pixl;
    int pos;
    int cut;
    int maxl;
    int size;
    int minval;
    int* result;
};

#endif // COMPRESS_H
