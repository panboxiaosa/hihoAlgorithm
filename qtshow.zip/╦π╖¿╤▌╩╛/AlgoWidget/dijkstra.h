#ifndef DIJKSTRA_H
#define DIJKSTRA_H

#include <vector>
#include <string>

using namespace std;

#define MAXDIST 2048

struct edge{
    int point1;
    int point2;
    int length;
};

class dijkstra
{
private:
    int** distMatrix;
    int* matrixHolder;
    int totalpoint;
    vector<int> addedPoint;
    vector<int> notAddedPoint;
    vector<int> eachDist;
    vector<string> route;
    vector<int> initPoint;
    vector<edge> initEdge;
    int nextvisit;
    int status;
    int mindist;
    int minpoint;
public:
    dijkstra();
    ~dijkstra();
    bool step();
    void finish();
    void clear();
    void setInit(vector<int> points,vector<edge> edges,int start);
    vector<string>& getRoutes();
    vector<int>& getDist();
    vector<int>& getAddedPoints();
    int getnowvisit();
    int getminpoint();
    int getmindist();
    int getstatus();

};

#endif // DIJKSTRA_H
