#include "compress.h"


compress::compress()
{
}

compress::~compress(){
    clear();
}

bool compress::step(){
    if(pos  > size){
        return false;
    }
    if(cut > pos || cut >= 256){
        result[pos] = minval;
        pos++;
        maxl = pixl[pos];
        minval = result[pos - 1] + maxl + 11;
        cut = 2;
    }else{
        if(maxl < pixl[pos - cut + 1]){
            maxl = pixl[pos - cut + 1];
        }
        if(minval > result[pos - cut] + maxl*cut + 11){
            minval = result[pos - cut] + maxl*cut + 11;
        }
        cut++;
    }
    return true;
}

void compress::finish(){
    while(step());
}

void compress::clear(){
    delete[] pixels;
    delete[] result;
    delete[] pixl;
}

int* compress::getresult(){
    return result;
}

int* compress::getpixl(){
    return pixl;
}

int compress::length(int input){
    int i = 1; input /= 2;
    while(input > 0){
        input /= 2;
        i++;
    }
    return i;
}

int compress::getpos(){
    return pos;
}

int compress::getcut(){
    return cut;
}

void compress::init(int* input, int size){
    pixels = new int[size + 1];
    result = new int[size + 1];
    pixl = new int[size + 1];
    pixels[0] = 0;
    for(int i = 1; i <= size; i++){
        pixels[i] = input[i - 1];
    }
    for(int i = 0; i <= size; i++){
        result[i] = 0;
    }
    for(int i = 1; i <= size; i++){
        pixl[i] = length(pixels[i]);
    }
    this->size = size;
    pos = 1;
    cut = 1;
    maxl = 0;
}

int compress::getsize(){
    return size;
}

int* compress::getpixels(){
    return pixels;
}

int compress::getmaxl(){
    return maxl;
}

int compress::getminval(){
    return minval;
}

