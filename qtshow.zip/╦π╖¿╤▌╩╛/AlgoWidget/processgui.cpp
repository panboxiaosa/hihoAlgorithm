#include "processgui.h"
#include "ui_processgui.h"

ProcessGUI::ProcessGUI(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ProcessGUI)
{
    ui->setupUi(this);
}

ProcessGUI::~ProcessGUI()
{
    delete ui;
}

void ProcessGUI::on_ProcessGUI_destroyed()
{
    delete ui;
    close();
}

void ProcessGUI::on_pushButton_clicked()
{
    on_ProcessGUI_destroyed();
}
