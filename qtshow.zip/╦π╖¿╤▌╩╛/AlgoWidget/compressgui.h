#ifndef COMPRESSGUI_H
#define COMPRESSGUI_H

#include <QDialog>
#include "compress.h"

namespace Ui {
class CompressGUI;
}

class CompressGUI : public QDialog
{
    Q_OBJECT

public:
    explicit CompressGUI(QWidget *parent = 0);
    ~CompressGUI();
    void init();
    void setwidget();

private slots:
    void on_CompressGUI_destroyed();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::CompressGUI *ui;
    compress problem;
};

#endif // COMPRESSGUI_H
